morse-code
==========

A simple utility to translate English into More code and vice-a-versa. It will also be able to play back the code featuring a fancy GUI with letter conversion charts.
