# Morse
Morse Code Practice Terminal Program
Gives Morse Code audio at fixed rate, then prints in _. notation. This can be changed in the while loop in the main method of Program.cs. Will add command line args in later commit.
