using System;

namespace Morse
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

