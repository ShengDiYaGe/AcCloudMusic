using System;

namespace Morse
{
	public class InternationalMorse
	{
		public InternationalMorse ()
		{
		}
	}
}

