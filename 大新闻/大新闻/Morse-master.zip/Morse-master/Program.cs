using System;

namespace Morse
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Morse morse = new Morse(".//InternationalMorse.txt");
		}
	}
}
