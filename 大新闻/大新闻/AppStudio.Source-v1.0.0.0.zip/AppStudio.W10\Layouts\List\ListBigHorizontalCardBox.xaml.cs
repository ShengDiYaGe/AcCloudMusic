namespace AppStudio.Layouts.List
{
    public sealed partial class ListBigHorizontalCardBox : ListLayoutBase
    {
        public ListBigHorizontalCardBox()
        {
            this.InitializeComponent();
        }
    }
}
