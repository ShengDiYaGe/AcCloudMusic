﻿WINDOWS APP STUDIO. GENERATED CODE README

This folder contains the code for the app you created in Windows App Studio.
It contains projects for an early version of Windows 10.

To compile this version you will need Visual Studio 2015.

If you want to publish this app in the store, dont forget to update your privacy terms.

Help and support in the Windows App Studio Forum: 
http://social.msdn.microsoft.com/Forums/wpapps/en-US/home?forum=wpappstudio