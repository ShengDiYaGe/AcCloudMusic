namespace AppStudio.Layouts.List
{
    public sealed partial class ListTextCard : ListLayoutBase
    {
        public ListTextCard() : base()
        {
            this.InitializeComponent();
        }
    }
}
