namespace AppStudio.Layouts.List
{
    public sealed partial class ListBigVerticalCardBox : ListLayoutBase
    {
        public ListBigVerticalCardBox()
        {
            this.InitializeComponent();
        }
    }
}
